<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JLPT extends Model
{
    //Table Name
    //protected $table = 'JLPT';
    // Primary Key
    public $primaryKey = 'ID_JLPT';
}
