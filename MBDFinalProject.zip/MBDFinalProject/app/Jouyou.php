<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jouyou extends Model
{
        //Table Name
        protected $table = 'jouyous';
        // Primary Key
        public $primaryKey = 'ID_Jouyou';
}
