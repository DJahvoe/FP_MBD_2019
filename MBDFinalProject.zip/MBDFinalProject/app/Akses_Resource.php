<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Akses_Resource extends Model
{
    //Table Name
    //protected $table = 'Akses';
    // Primary Key
    public $primaryKey = 'ID_Akses';
}
