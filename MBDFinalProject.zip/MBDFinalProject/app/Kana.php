<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kana extends Model
{
        //Table Name
        protected $table = 'kanas';
        // Primary Key
        public $primaryKey = 'ID_Kana';
}
