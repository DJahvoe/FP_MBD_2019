<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
        //Table Name
        //protected $table = 'Review';
        // Primary Key
        public $primaryKey = 'ID_Review';
}
