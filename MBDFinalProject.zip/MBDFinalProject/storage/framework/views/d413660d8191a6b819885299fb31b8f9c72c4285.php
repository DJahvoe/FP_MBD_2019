<?php $__env->startSection('content'); ?>
    <h1>Search</h1>
    <?php if(count($kanjis) > 1): ?>
        <?php $__currentLoopData = $kanjis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kanji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
                <h3><?php echo e($kanji->K_Kanji); ?> : <?php echo e($kanji->K_Keyword); ?></h3>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No kanji found</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DeveloperTools\xamppREINSTALL\htdocs\MBDFinalProject\resources\views/pages/searchKJ.blade.php ENDPATH**/ ?>