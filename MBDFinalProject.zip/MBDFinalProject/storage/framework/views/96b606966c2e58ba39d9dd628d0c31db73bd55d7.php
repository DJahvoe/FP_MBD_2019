<?php $__env->startSection('content'); ?>
        <h1>INDEX</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DeveloperTools\xamppREINSTALL\htdocs\MBDFinalProject\resources\views/pages/index.blade.php ENDPATH**/ ?>