<?php $__env->startSection('content'); ?>
        <style>
                table {
                    font-family: arial, sans-serif;
                    border-collapse: collapse;
                    width: 100%;
                  }
                  
                  td, th {
                    border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px;
                  }
                  
                  tr:nth-child(even) {
                    background-color: #dddddd;
                  }
        </style>
        <h1>Search</h1>
        <div class="row">
                <div class="col-sm-2">
                        <form action="/search/N5">
                        <input type="submit" value="N5" class="btn btn-primary" style="font-size: 4rem;">
                        </form>
                </div>
                
                <div class="col-sm-2">
                        <form action="/search/N4">
                        <input type="submit" value="N4" class="btn btn-info" style="font-size: 4rem;">
                        </form>
                </div>
                <div class="col-sm-2">
                        <form action="/search/N3">
                        <input type="submit" value="N3" class="btn btn-success" style="font-size: 4rem;">
                        </form>
                </div>
                <div class="col-sm-2">
                        <form action="/search/N2">
                        <input type="submit" value="N2" class="btn btn-warning" style="font-size: 4rem;">
                        </form>
                </div>
                <div class="col-sm-2">
                        <form action="/search/N1">
                        <input type="submit" value="N1" class="btn btn-danger" style="font-size: 4rem;">
                        </form>
                </div>
        </div>
        <div class="row">
                <div class="col-sm-2">
                        <form action="/search/J1">
                        <input type="submit" value="E1" class="btn btn-primary" style="font-size: 4rem;">
                        </form>
                </div>
                
                <div class="col-sm-2">
                        <form action="/search/J2">
                        <input type="submit" value="E2" class="btn btn-info" style="font-size: 4rem;">
                        </form>
                </div>
                <div class="col-sm-2">
                        <form action="/search/J3">
                        <input type="submit" value="E3" class="btn btn-success" style="font-size: 4rem;">
                        </form>
                </div>
                <div class="col-sm-2">
                        <form action="/search/J4">
                        <input type="submit" value="E4" class="btn btn-warning" style="font-size: 4rem;">
                        </form>
                </div>
                <div class="col-sm-2">
                        <form action="/search/J5">
                        <input type="submit" value="E5" class="btn btn-danger" style="font-size: 4rem;">
                        </form>
                </div>
                <div class="col-sm-2">
                        <form action="/search/J6">
                        <input type="submit" value="E6" class="btn btn-warning" style="font-size: 4rem;">
                        </form>
                </div>
                <div class="col-sm-2">
                        <form action="/search/JJH">
                        <input type="submit" value="JH" class="btn btn-danger" style="font-size: 4rem;">
                        </form>
                </div>
        </div>
    <?php if(count($kanjis) >= 1): ?>
    <div class="table table-dark">
            <thead>
            <tr>
                <th scope="row">Kanji</th>
                    <th scope="col">Keyword</th>

                    <th scope="col">StrokeCount</th>
                    <th scope="col">LessonNo</th>

                    <th scope="col">Jouyou</th>
                    <th scope="col">JLPT</th>

            </tr>
        </thead>
    </div>
        <?php $__currentLoopData = $kanjis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kanji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <tbody>
                        <tr>
                                <th scope="row"><?php echo e($kanji->K_Kanji); ?></th>
                                <td><?php echo e($kanji->K_Keyword); ?></td>
        
                                <td><?php echo e($kanji->K_StrokeCount); ?></td>
                                <td><?php echo e($kanji->K_LessonNo); ?></td>
        
                                <td><?php echo e($kanji->K_JouYou); ?></td>
                                <td><?php echo e($kanji->K_JLPT); ?></td>
                                
                        </tr>
                </tbody>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($kanjis->links()); ?>

    <?php else: ?>
        <p>No kanji found</p>
    <?php endif; ?>
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DeveloperTools\xamppREINSTALL\htdocs\MBDFinalProject\resources\views/pages/search.blade.php ENDPATH**/ ?>