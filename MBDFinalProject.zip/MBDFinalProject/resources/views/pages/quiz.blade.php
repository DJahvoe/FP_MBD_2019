@extends('layouts.app')

@section('content')
        <h1>これはQuizです</h1>
@endsection