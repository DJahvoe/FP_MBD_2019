@extends('layouts.app')

@section('content')
        <h1>これはコースです</h1>
@endsection