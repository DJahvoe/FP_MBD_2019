@extends('layouts.template')

@section('content')
        <h1>USER</h1>
@endsection